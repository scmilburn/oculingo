﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class example : MonoBehaviour {

    private VoiceRec.VoiceClass obj;
    private string word;

    void Start() {
        obj = new VoiceRec.VoiceClass();
        
        //set of commands : replace with set of commands to be recognized
        string[] str= { "left", "right", "down", "up", "izquierda", "derecho", "abajo", "arriba", "mahzana" };
        HashSet<string> tokens = new HashSet<string>(str);
        //string[] str = { "left", "right", "down", "up", "isquiarda", "dayrectcho", "abajo", "arriba" };
        //string[] espanol = {  "izquierda", "derecho", "abajo", "arriba" };
        obj.initRecog(str);
        
	}
	
	void Update () {
        word = obj.getWord();
        
        if (word != null && word != "")
        {
            print(word.ToString());
            WindowsVoice.theVoice.speak("Good.");
            /*
            switch (word)
            {
                case "left":
                    print("Voice input : ENG: left");
                    break;
                case "right":
                    print("Voice input : ENG: right");
                    break;
                case "down":
                    print("Voice input : ENG: down");
                    break;
                case "up":
                    print("Voice input : ENG: up");
                    break;
                //case "izquierda":
                case "isquiarda":
                    print("Voice input : SP: left");
                    break;
                case "derecho":
                    print("Voice input : SP: right");
                    break;
                case "abajo":
                    print("Voice input : SP: down");
                    break;
                case "arriba":
                    print("Voice input : SP: up");
                    break;
            }
            */
            //print(word.ToString());
        }
	}
}

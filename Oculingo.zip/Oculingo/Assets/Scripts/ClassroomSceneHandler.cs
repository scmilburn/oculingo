﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ClassroomSceneHandler : MonoBehaviour {

    public string nativeLang;   // Langs declared from TitleScene
    public string targetLang;
    public GameObject langObjectSet;    // GameObject that stores several Language Objects

    private VoiceRec.VoiceClass voiceRec;
    private string voiceResult;

    // Use this for initialization
    void Start () {
        // Instnanciate/gather Lang variables, default English
        voiceRec = new VoiceRec.VoiceClass();
        string[] dict = { "door", "desk", "table", "bookshelf", "fan", "computer", "printer", "chair", "book", "window", "screen", "projector" };
        
    }
	
	// Update is called once per frame
	void Update () {
	
	}
}
